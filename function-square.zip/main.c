/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>
void printsquare(int n);

int main()
{
    int n;
    scanf("%d",&n);
    printsquare(n);
    printf("%f",pow(n,2));
 
    return 0;
}
void printsquare(int n){
  //  printf("%f",pow(2,n));
}
