/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int adhar[5];
    for(int i=0;i<=4;i++){
        scanf("%d",&adhar[i]);
    }
    for(int i=0;i<=4;i++){
        printf("%d",adhar[i]);
    }

    return 0;
}
