/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
void printtable(int a);
int n;
int main()
{ 
   int a;
   scanf("%d",&a);
    scanf("%d",&n);
   

  printtable( a);
  
   
   return 0;
}
void printtable(int a){
    for(int i=1;i<=n;i++){
        printf("%d\n",i*a);
    }
   
}
