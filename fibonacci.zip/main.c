/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int a,b,result,n,i;
   scanf("%d",&n);
   a=0;
   b=1;
   for(i=1;i<=n;i++){
       printf("%d",a);
       result=a+b;
       a=b;
       b=result;
   }
   printf("%d",result);
   

    return 0;
}
