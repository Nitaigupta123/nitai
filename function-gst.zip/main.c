/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
void calculateprice(float n);

int main()
{
    float n;
    scanf("%f",&n);
    calculateprice( n);
    return 0;
}
void calculateprice(float n){
    n=n+(0.18*n);
    printf("%f",n);
}
