/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int
main ()
{
  int sum = 0;
  int num[] = { 1, 2, 3, 4, 5 };
  for (int i = 0; i <= 5; i++)
    {
      if (num[i] % 2 == 0)
	sum = sum + num[i];

    }
  printf ("\n%d", sum);

  return 0;
}
