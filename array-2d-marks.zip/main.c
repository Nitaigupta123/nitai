/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
   int marks[2][3];
   marks[0][0]=90;
   marks[0][1]=89;
   marks[0][2]=78;
   
   
    marks[1][0]=4;
   marks[1][1]=8;
   marks[1][2]=9;
   printf("%d",marks[1][2]);
    return 0;
}
